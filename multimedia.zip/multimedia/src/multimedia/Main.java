package multimedia;

import java.io.*;
//import java.util.LinkedList;
//import java.util.List;

public class Main {
	
	public static void main(String[] args) {

		String imagePath = "C:\\Users\\RanaO\\Desktop\\multimedia\\Baby-Godfather.jpg";
		String base64ImageString = Base64Image.encoder(imagePath);
		Base64Image.writeText_toFile("C:\\Users\\RanaO\\Desktop\\multimedia\\Baby-Godfather.txt",base64ImageString);
		// TODO Auto-generated method stub
		System.out.println("Running project...");
		ShanonFanoAlgorotihm process=new ShanonFanoAlgorotihm();
		
		System.out.println("Read Text\n");
//		process.readTxt("D:\\eclipse-workspace\\multimedia\\text.txt");// File name text.txt
		process.readTxt("C:\\Users\\RanaO\\Desktop\\multimedia\\Baby-Godfather.txt");
		System.out.println("\nTotal Count of Symbols: "+process.getTotalCountSymbols()+"\n");
		
		System.out.println("\nCounting probability:");
		process.countProbabilty();
		
		System.out.println("\nEncoding Letters: ");
		process.encodingLetters(0, process.getValues().size(),"");
		
		
		process.showEndodedSymbols();
		
		
		System.out.println("\nEncoding Text and Save to encodedText.txt");
		process.encodingText();
		
		System.out.println("\nEncoding binary sequence with Hamming Code: ");
		process.encodingToHammingCode("encodedText.txt");//File name  encodedText.txt
		
		System.out.println("\nAdd randomly errors To check : ");
		process.addError("encodedHammingCode.txt");//File name  encodedHammingCode
		
		System.out.println("\nDecoding Hamming Code and Fixing errors: ");
		process.fixErrorsAndDecodeHammingCode("hammingCodeWithErrors.txt");//File Name hammingCodeWithErrors
		
		System.out.println("\nDecoding Text and Save to decocededText.txt");
		process.decodingText("decodedHammingCode.txt");// File name encodedText.txt
		
		process.entropu();
		base64ImageString="";
		try { 
            BufferedReader in = new BufferedReader( 
                        new FileReader("decodedText.txt")); 
  
            String mystring; 
            while ((mystring = in.readLine()) != null) { 
                base64ImageString += mystring; 
            } 
        } 
        catch (IOException e) { 
            System.out.println("Exception Occurred" + e); 
        } 
		Base64Image.decoder(base64ImageString, "C:\\Users\\RanaO\\Desktop\\multimedia\\decoderimage2.jpg");

	}
}
