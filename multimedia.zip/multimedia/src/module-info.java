module multimedia {
}